// Sélection des éléments ayant la classe "getClass"
const elements = document.querySelectorAll(".getClass");

// Fonction pour afficher la valeur correspondante en gras
function afficherLegende(event) {
    // Récupération de la valeur de l'attribut data-legende
    const legende = event.target.dataset.legende;
    const monElement = document.getElementById(legende);
    // Ajout de style à l'élément
    monElement.style.fontWeight = "bold";
}

// Fonction pour retirer le gras de la valeur correspondante
function quitterSurvol(event) {
    const legende = event.target.dataset.legende;
    const monElement = document.getElementById(legende);
    // Retrait de style à l'élément
    monElement.style.fontWeight = "";
}

// Ajout d'un écouteur d'événement pour chaque élément pour le survol
elements.forEach(element => {
    element.addEventListener("mouseover", afficherLegende);
});

// Ajout d'un écouteur d'événement pour chaque élément pour le quitté du survol
elements.forEach(element => {
    element.addEventListener("mouseout", quitterSurvol);
});