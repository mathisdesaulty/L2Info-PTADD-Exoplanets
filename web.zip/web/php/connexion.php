<?php

define("SERVEUR","db");
define("USER","root");
define("MDP","root");
define("Annuaire","tp3");


function connexionBd($Serveur="localhost",$User="user",$Mdp="user",$Bd="annuaire"){
  // gestion de la connexion
      try
      {
          $connexion= new PDO('mysql:host='.$Serveur.';dbname='.$Bd, $User, $Mdp);
          $connexion->exec("SET CHARACTER SET utf8"); //Gestion des accents
          return $connexion;
      }
  
  //gestion des erreurs
      catch(Exception $e)
      {
          echo 'Erreur : '.$e->getMessage().'<br />';
          echo 'N° : '.$e->getCode();
      }
  }

?>
