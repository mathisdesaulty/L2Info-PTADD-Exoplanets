<?php
include 'connexion.php';  

$connexion=connexionBd();

//EXERCICE 1

//Création de la requete
$requete= "SELECT * FROM contacts";

//Envoi de la requete
$rep=$connexion->query($requete);

//recup des donnees
$listeContacts=$rep->fetchAll(PDO::FETCH_OBJ);



//EXERCICE 2

///Création de la requete
$requete= "SELECT contacts.id as id_contact, contacts.nom, prenom, telephone, mail, annee_naissance, ville.nom as nomVille FROM contacts 
            inner join ville on contacts.ville_id = ville.id WHERE ville.nom='la rochelle'";
echo $requete;

//Envoi de la requete
$rep=$connexion->query($requete);

//Recuperation du résultat
$listeLaRochelle=$rep->fetchALL(PDO::FETCH_ASSOC);

var_dump($listeLaRochelle);

//EXERCICE 3

$req3="Select * from ville WHERE code_postal=17100";

$contactExiste=$connexion->query($req3);

if($contactExiste->rowCount()==0){

    //Création de la requete
    $requete= "INSERT INTO ville VALUES(null,'saintes',17100)";

    $reqInsertion=$connexion->exec($requete);
}

//EXERCICE 4
$requete_prepare1=$connexion->prepare("SELECT contacts.nom, prenom FROM contacts inner join ville v on contacts.ville_id = v.id WHERE v.nom=:nomVille");
$val='la rochelle';
$requete_prepare1->bindParam(':nomVille',$val);
$requete_prepare1->execute();

//Recuperation du resultat
$resultRequetePrepare1=$requete_prepare1->fetchAll(PDO::FETCH_OBJ);


//EXERCICE 5
if (isset($_POST["nomVille"]))
{		
    $nomVille=strtolower(htmlspecialchars($_POST["nomVille"]));  // le nom de mes villes sont en minuscules

    //utilisation de la requête préparée
    $requete_prepare1->execute(array('nomVille'=>$nomVille));

    $resultRequeteFormulaire=$requete_prepare1->fetchAll(PDO::FETCH_OBJ);

}


//EXERCICE 6
if(isset($_POST["send"]))
{
    
    if (!empty($_POST["nom"]) && !empty($_POST["prenom"]) && !empty($_POST["email"]))
    {
        //print_r($_POST);
        $nom=strtolower(htmlspecialchars($_POST["nom"]));
        $prenom=strtolower(htmlspecialchars($_POST["prenom"]));
        $email=htmlspecialchars($_POST["email"]);

        //Création de la requete
        $requete = "INSERT INTO contacts (nom, prenom, mail) VALUES (:nom,:prenom, :email)";
        //echo $requete;
        $req_insertion_contact = $connexion->prepare($requete);
        $req_insertion_contact->bindParam(':nom',$nom);
        $req_insertion_contact->bindParam(':prenom',$prenom);
        $req_insertion_contact->bindParam(':email',$email);

        //Envoi de la requete
        $repInsertionForm = $req_insertion_contact->execute();

    }
}

?>


<!DOCTYPE html>
<html lang="fr">
    <head>
        <link rel="stylesheet" href="../css/styles.css">
        <title>TD 3</title>
        
        <meta charset="utf-8" />

    </head>

    <body>

        <!--EXERCICE 1 -->
        <h2>Mes contacts</h2>		

        <table border="1">
            <tr>
                <th>id</th>
                <th>nom</th>
                <th>prenom</th>
                <th>telephone</th>
                <th>mail</th>
                <th>annee naissance</th>
                <th>Ville_id</th>
            </tr>

            <?php foreach($listeContacts as $unContact) : ?>    
            <tr>
                <?php foreach($unContact as $info) : ?>
                <td><?= $info ?> </td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </table>


        <!--EXERCICE 2 -->
        <h2>Requete avec critère</h2>
        <table>
            <tr>
                <?php foreach($listeLaRochelle as $unContact) : ?>    
                <?php foreach($unContact as $info): ?>
                <td><?= $info ?> </td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </table>

        <!--EXERCICE 3 -->
        <h2>Requête d'insertion</h2>


        <?php if(isset($reqInsertion)):?>  
        <p>Insertion réussie</p> 
        <?php else:?>
        <p>la ville existe déja</p>
        <?php endif; ?>

        <!--EXERCICE 4 -->
        <h2>Requête préparée</h2>
        <table>

            <?php foreach($resultRequetePrepare1 as $unContact):?>            
            <tr>
                <?php foreach($unContact as $val) :?>
                <td><?=$val?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </table>



        <!--EXERCICE 5 -->
        <h2>Requête avec critère issu d'un formulaire</h2>

        <form action="../php/index.php" enctype="multipart/form-data" method="post">
            <p>ville <input type="text" name="nomVille" /></p>
            <p><input type="submit" /></p>
        </form>	

        <?php if(isset($resultRequeteFormulaire)):?>
        <table>
            <?php foreach($resultRequeteFormulaire as $unContact):?>
            <tr>
                <?php  foreach($unContact as $val): ?>
                <td><?=$val?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>





        <!--EXERCICE 6 -->
        <h2>Requête d'insertion avec données issues d'un formulaire</h2>

        <form action="../php/index.php" method="post">
            <p>Nom <input type="text" name="nom" /></p>
            <p>Prénom <input type="text" name="prenom" /></p>
            <p>email<input type="email" name="email" /></p>
            <p><input type="submit" name="send"/></p>
        </form>


        <?php if (isset($repInsertionForm) && $repInsertionForm>0):?>
        <p>Insertion réussie</p>
        <?php else: ?>
        <p>erreur insertion</p>

        <?php endif; ?>









    </body>
</html>
