<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagramme Circulaire Adaptatif</title>
    <link rel="stylesheet" href="CSS/stylesheet.css">
</head>
<body>
<div id="camembert">
    <div class="pie" data-legende="liVert" style="--percentage: 30; --color: blue;"></div>
    <div class="pie" data-legende="liBleu" style="--percentage: 25; --color: green;"></div>
    <div class="pie" data-legende="liRouge" style="--percentage: 20; --color: red;"></div>
    <div class="pie" data-legende="liJaune" style="--percentage: 25; --color: orange;"></div>
</div>

<ul id="legende">
    <li id="liVert">30% Blé</li>
    <li id="liBleu">25% Maïs</li>
    <li id="liRouge">20% Avoine</li>
    <li id="liJaune">25% Orge</li>
</ul>

<script src="JavaScript/javascript.js"></script>
</body>
</html>
