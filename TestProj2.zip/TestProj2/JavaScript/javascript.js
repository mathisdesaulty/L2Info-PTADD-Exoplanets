document.addEventListener('DOMContentLoaded', function () {
    const elements = document.querySelectorAll(".pie");

    function afficherLegende(event) {
        const legende = event.target.dataset.legende;
        const monElement = document.getElementById(legende);
        if (monElement) {
            monElement.style.fontWeight = "bold";
        }
    }

    function quitterSurvol(event) {
        const legende = event.target.dataset.legende;
        const monElement = document.getElementById(legende);
        if (monElement) {
            monElement.style.fontWeight = "";
        }
    }

    elements.forEach(element => {
        element.addEventListener("mouseover", afficherLegende);
        element.addEventListener("mouseout", quitterSurvol);
    });
});
